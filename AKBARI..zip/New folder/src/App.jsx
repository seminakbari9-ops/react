import FindClinic from "./FindClinic";
function App() {

  return <FindClinic />;

}

export default App;