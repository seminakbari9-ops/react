 import "./BlogPost.css";
 function BlogPost() {
    return (


      <div className="blog-post">

      <img

        className="blog-image"

       scr="https://images.unsplash.com/photo-1633356122544-f134324a6cee"

        alt="Blog"

      />

      <h2 className="blog-title">

        Learn React Components

      </h2>

      <p className="blog-author">

        By Ahmad • Sep 14, 2026

      </p>

      <p className="blog-description">

        Learn the basics of React components and JSX...

      </p>

      <button className="read-more">

        Read More

      </button>

    </div>

  );

}

export default BlogPost;